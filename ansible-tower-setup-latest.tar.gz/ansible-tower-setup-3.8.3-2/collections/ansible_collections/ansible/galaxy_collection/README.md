# Ansible Galaxy Collection

Contains plugins, roles, etc. for managing and configuring a local Galaxy server.

To learn more about Galaxy and how to install a local server, [visit the GalaxyNG project](https://github.com/ansible/galaxy_ng).

## Contents

### Roles 

- [post_install_config](./roles/post_install_config)
